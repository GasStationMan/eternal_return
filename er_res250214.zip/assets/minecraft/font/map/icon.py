import os
from PIL import Image

#보스바 gui제작을 편하게 하기 위한
#폰트 설정기

#보스바 폰트를 위한 이미지 : BImage 클래스
class BImage():
    def __init__(self, imageDirectory : str, imageName : str):
        '''BImage 객체를 생성합니다

        @param imageDirectory : 이미지 파일의 절대경로입니다. os.getcwd()를 이용하십시오.
        @param imageName      : 이미지 파일의 확장자 포함 이름입니다.
        '''
        
        imageFileName : list[str] = imageName.split(".")

        self.__xSize : int
        self.__ySize : int
        self.__imageName : str = imageFileName[0] #여기에는 이미지의 이름이 들어가요
        self.__fileType : str = imageFileName[1]  #여기에는 이미지의 확장자가 들어가요
        self.__fullFileName : str = imageName     #여기에는 이미지의 전체 이름 (ex : aaa.jpg)가 들어가요

        self.__imgFile = Image.open(imageDirectory)
        self.__xSize, self.__ySize = self.__imgFile.size
    
    def getSize(self) -> int :
        return self.__xSize, self.__ySize
    
    def getSizeX(self) -> int :
        return self.__xSize
    
    def getSizeY(self) -> int :
        return self.__ySize
    
    def getImageName(self) -> str :
        return self.__imageName

    def getFileType(self) -> str :
        return self.__fileType
    
    def getFullFileName(self) -> str :
        return self.__fullFileName
    

    
    



    
def toJson(fileName : str) -> str:
    if(fileName.endswith(".")):
        return fileName + "json"
    else:
        return fileName + ".json"




def main():
    current_location : str = os.getcwd()

    fileList : list[str] = os.listdir(current_location)

    imageFileDir = current_location + "\\images"
    imageFileList : list[str] = os.listdir(imageFileDir)

    bImgList : list[BImage] = []

    #이미지 파일을 읽어와서 보스바 이미지 인스턴스 생성 후 bImgList 리스트에 삽입
    for imageFile in imageFileList :

        #현재 디렉토리\\areas\\...
        directory = os.path.join(imageFileDir,imageFile)
        
        if(imageFile[-2:] == "py" or os.path.isdir(directory)):
            continue
            
        bImgList.append(BImage(directory, imageFile))

    #BImage를 순회하면서 해당하는 json파일을 생성한다.
    for bImageFile in bImgList:
        
        #현재 디렉토리\\...
        directory = os.path.join(current_location,toJson(bImageFile.getImageName()))

        if(bImageFile.getFileType() == "py" or os.path.isdir(directory)):
            continue

        if(bImageFile.getImageName() == "hyper_loop"):
            convertToJsonFontFile(directory, bImageFile.getImageName(), 800)
        elif(bImageFile.getImageName() == "icon"):
            convertToJsonFontFile(directory, bImageFile.getImageName(), bImageFile.getSizeY() / 2)
        else:
            convertToJsonFontFile(directory, bImageFile.getImageName(), bImageFile.getSizeY() / 3)
    

        print("[TDanfung BSwing IconModifier] modifying..." + bImageFile.getImageName())
    
    os.system("pause")
    


def convertToJsonFontFile(directory : str, fileName : str , imageJsonHeigtValue : int):

    '''.json 확장자의 폰트 파일을 생성하기 위한 함수
    
        @param directory : jsonFile을 내보낼 디렉토리
        @param fileName  : 확장자 없는 순수 파일 이름
        @param imageJsonHeightValue : BImage 클래스에서 .getSizeY()를 호출하여 얻은 값
    '''

    
    f = open(directory,"w")
    
    strList : list[str] = []
    strList.append("{\"providers\":[\n")
    fillJsonFileContents(strList , fileName, imageJsonHeigtValue)
    strList.append("]}")

    for strToInput in strList:
        f.write(strToInput)
    
    f.close()



def fillJsonFileContents(strList : list[str], fileName : str, imageJsonHeigtValue : int):
    """
    .json 파일에 작성할 내용을 적어 넣는 곳
    """


    iconDir : str = "minecraft:font/area/" + fileName + ".png"
    height : int = 4096
    for i in range(512):
        inputString = "{\"type\": \"bitmap\",\"file\": \""+ iconDir +"\",\"ascent\": "+ str(imageJsonHeigtValue - i) +", \"height\": "+ str(imageJsonHeigtValue) +",\"chars\": [\"\\u" + hex(height + i)[2:] + "\"]}"

        if(i < 511):
            inputString = inputString + ",\n"

        strList.append(inputString)
        #print(inputString)







if __name__ == "__main__":

    main()



